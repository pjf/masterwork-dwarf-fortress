package cz.zweistein.df.soundsense.gui.control.configuration;

public interface IxmlFileInfoPanel {
	
	void setPath(String path);

}
